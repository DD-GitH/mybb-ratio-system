<?php
$l['desc_plugin'] = "Le systéme ratio consiste à faire une division pour restreindre les réponses aux sujets.";
$l['title_plugin'] = "Système Ratio";
$l["group_title"] = "Système Ratio";
$l["group_desc"] = "Options pour le système ratio";
$l["minimum_title"] = "Ratio minimal";
$l["minimum_desc"] = "Rentrez le ratio requis pour pouvoir répondre aux sujets. <strong>Exemple : 0.1</strong>";
$l["avoidedgroups_title"] = "Groupes speciaux";
$l["avoidedgroups_desc"] = "Entez les IDs des groupes qui auront un ratio illimité. <strong>Exemple (pour les administrateurs et les modérateurs) : 4, 6";
$l["avoidedfids_title"] = "Forums ignorés";
$l["avoidedfids_desc"] = "Entrer les FIDs des forums où le systéme ratio est ignoré. <strong>Exemple : 2, 4";