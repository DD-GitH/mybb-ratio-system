ENGLISH

Plugin name : Ratio System
Author : DarSider/AmazOuz
Author's website : http://www.electrikforums.fr
Version : 1.0
Compability : 1.6 & 1.8

Notes:
------
No commercial use
For suggestions go to the author's website or return to the MyBB Community Forums thread of this plugin. Or email us at :
stanwaw@outlook.fr

// -----------------------------------------

FRENCH

Nom du plugin : Ratio System
Auteur : DarSider/AmazOuz
Site de l'auteur : http://www.electrikforums.fr
Version : 1.0
Compabilit� : 1.6 & 1.8

Remarques:
------
No commercial use
Pour les suggestions, aller vers le MyBB Community Forums (ENG) ou mybb.fr, et r�pondez au sujet du plugin dans le forum T�l�chargements. 
Vous pouvez aussi aller vers le site de l'auteur ou bien envoyer un mail au stanwaw@outlook.fr

